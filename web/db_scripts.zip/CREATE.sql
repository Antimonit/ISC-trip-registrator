-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `homestead`;
CREATE DATABASE `homestead` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `homestead`;

DROP TABLE IF EXISTS `accommodation`;
CREATE TABLE `accommodation` (
  `id_accommodation` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) NOT NULL,
  `full_name_eng` varchar(45) NOT NULL,
  `abbreviation` char(4) NOT NULL,
  PRIMARY KEY (`id_accommodation`),
  UNIQUE KEY `accommodation` (`full_name`),
  UNIQUE KEY `id_accommodation` (`id_accommodation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `arrivals`;
CREATE TABLE `arrivals` (
  `id_user` int(10) unsigned NOT NULL,
  `arrival` datetime NOT NULL,
  `id_transportation` tinyint(3) unsigned NOT NULL,
  `buddy_status` tinyint(3) unsigned DEFAULT NULL,
  `buddy_information` text,
  PRIMARY KEY (`id_user`),
  KEY `fk_transportations` (`id_transportation`),
  CONSTRAINT `fk_exchange_students` FOREIGN KEY (`id_user`) REFERENCES `exchange_students` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_transportations` FOREIGN KEY (`id_transportation`) REFERENCES `transportation` (`id_transportation`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP VIEW IF EXISTS `arrivals_buddies`;
CREATE TABLE `arrivals_buddies` (`exchange name` varchar(91), `exchange email` varchar(100), `arrival` datetime, `accommodation` varchar(45), `buddy name` varchar(91), `buddy mail` varchar(100));


DROP TABLE IF EXISTS `buddies`;
CREATE TABLE `buddies` (
  `id_user` int(10) unsigned NOT NULL,
  `id_faculty` tinyint(3) unsigned DEFAULT NULL,
  `about` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` enum('y','n') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `subscribed` tinyint(1) NOT NULL DEFAULT '1',
  `alive` enum('y','n') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `verified` enum('y','n','d') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `welcome_mail_sent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_login` timestamp NULL DEFAULT NULL,
  `agreement` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_partak` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_buddy` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`),
  KEY `id_faculty` (`id_faculty`),
  CONSTRAINT `buddies_ibfk_2` FOREIGN KEY (`id_faculty`) REFERENCES `faculties` (`id_faculty`) ON UPDATE CASCADE,
  CONSTRAINT `fk_people` FOREIGN KEY (`id_user`) REFERENCES `people` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `function` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(10) unsigned DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id_country` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(44) NOT NULL,
  `two_letters` char(2) NOT NULL,
  `three_letters` char(3) NOT NULL,
  PRIMARY KEY (`id_country`),
  UNIQUE KEY `id_country` (`id_country`),
  UNIQUE KEY `two_letters` (`two_letters`),
  UNIQUE KEY `three_letters` (`three_letters`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id_event` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `datetime_from` timestamp NULL DEFAULT NULL,
  `visible_from` timestamp NULL DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook_url` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `modified_by` int(10) unsigned NOT NULL,
  `cover` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` enum('normal','integreat','languages') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  PRIMARY KEY (`id_event`),
  KEY `modified_by` (`modified_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `events_ibfk_1` FOREIGN KEY (`modified_by`) REFERENCES `people` (`id_user`),
  CONSTRAINT `events_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `people` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `exchange_students`;
CREATE TABLE `exchange_students` (
  `id_user` int(10) unsigned NOT NULL,
  `id_country` smallint(5) unsigned NOT NULL,
  `id_accommodation` tinyint(3) unsigned NOT NULL,
  `id_faculty` tinyint(3) unsigned NOT NULL,
  `id_buddy` int(10) unsigned DEFAULT NULL,
  `buddy_timestamp` datetime DEFAULT NULL,
  `about` mediumtext COLLATE utf8mb4_unicode_ci,
  `school` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `want_buddy` enum('y','n') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `esn_card_number` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `esn_registered` enum('y','n') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `wants_present` enum('y','n') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `esn_card_number` (`esn_card_number`),
  KEY `fk_countries` (`id_country`),
  KEY `fk_accommodation` (`id_accommodation`),
  KEY `fk_faculties` (`id_faculty`),
  KEY `fk_buddies` (`id_buddy`),
  CONSTRAINT `fk_accommodation` FOREIGN KEY (`id_accommodation`) REFERENCES `accommodation` (`id_accommodation`) ON UPDATE CASCADE,
  CONSTRAINT `fk_buddies` FOREIGN KEY (`id_buddy`) REFERENCES `buddies` (`id_user`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_countries` FOREIGN KEY (`id_country`) REFERENCES `countries` (`id_country`) ON UPDATE CASCADE,
  CONSTRAINT `fk_faculties` FOREIGN KEY (`id_faculty`) REFERENCES `faculties` (`id_faculty`) ON UPDATE CASCADE,
  CONSTRAINT `fk_people2` FOREIGN KEY (`id_user`) REFERENCES `people` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `faculties`;
CREATE TABLE `faculties` (
  `id_faculty` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `faculty` varchar(38) NOT NULL,
  `abbreviation` varchar(4) NOT NULL,
  PRIMARY KEY (`id_faculty`),
  UNIQUE KEY `faculty` (`faculty`),
  UNIQUE KEY `id_faculty` (`id_faculty`),
  UNIQUE KEY `abbreviation` (`abbreviation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `galaxy_data`;
CREATE TABLE `galaxy_data` (
  `id_user` int(10) unsigned NOT NULL,
  `mail` varchar(255) NOT NULL,
  `sc` varchar(255) NOT NULL,
  `first` varchar(255) NOT NULL,
  `last` varchar(255) NOT NULL,
  `nationality` char(2) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  PRIMARY KEY (`id_user`),
  CONSTRAINT `galaxy_data_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `galaxy_roles`;
CREATE TABLE `galaxy_roles` (
  `id_galaxy_role` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `galaxy_role` varchar(255) NOT NULL,
  PRIMARY KEY (`id_galaxy_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `integreat_parties`;
CREATE TABLE `integreat_parties` (
  `id_event` int(10) unsigned NOT NULL,
  `countries` tinytext,
  `theme` tinytext,
  KEY `id_event` (`id_event`),
  CONSTRAINT `integreat_parties_ibfk_1` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`),
  CONSTRAINT `integreat_parties_ibfk_2` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id_language` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(30) NOT NULL,
  PRIMARY KEY (`id_language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `languages_events`;
CREATE TABLE `languages_events` (
  `id_event` int(10) unsigned NOT NULL,
  `where` tinytext,
  `where_url` tinytext,
  KEY `id_event` (`id_event`),
  CONSTRAINT `languages_events_ibfk_1` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(100) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `people`;
CREATE TABLE `people` (
  `id_user` int(10) unsigned NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `age` year(4) DEFAULT NULL,
  `sex` enum('M','F') DEFAULT NULL,
  `diet` enum('Vegetarian','Vegan','Fish only') DEFAULT NULL,
  `medical_issues` varchar(255) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `fk_people_users1` (`id_user`),
  CONSTRAINT `fk_people_users1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `preregistered_buddies`;
CREATE TABLE `preregistered_buddies` (
  `email` varchar(100) NOT NULL,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `resultsls2016`;
CREATE TABLE `resultsls2016` (
  `id_vote` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `bestvideo` char(3) DEFAULT NULL,
  `bestfood` char(3) DEFAULT NULL,
  `bestshow` char(3) DEFAULT NULL,
  `fb` text,
  PRIMARY KEY (`id_vote`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `resultsws2015`;
CREATE TABLE `resultsws2015` (
  `id_vote` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `bestvideo` char(3) DEFAULT NULL,
  `bestfood` char(3) DEFAULT NULL,
  `bestshow` char(3) DEFAULT NULL,
  `fb` text,
  PRIMARY KEY (`id_vote`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `resultsws2016`;
CREATE TABLE `resultsws2016` (
  `id_vote` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `bestperformance` char(3) NOT NULL,
  `bestfood` char(3) NOT NULL,
  `bestshow` char(3) NOT NULL,
  `fb` text NOT NULL,
  PRIMARY KEY (`id_vote`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id_role` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `semesters`;
CREATE TABLE `semesters` (
  `id_semester` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(45) NOT NULL,
  PRIMARY KEY (`id_semester`),
  UNIQUE KEY `semester_UNIQUE` (`semester`),
  UNIQUE KEY `id_semester_UNIQUE` (`id_semester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `semesters_has_exchange_students`;
CREATE TABLE `semesters_has_exchange_students` (
  `id_semester` tinyint(3) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_semester`,`id_user`),
  KEY `fk_students` (`id_user`),
  KEY `fk_semesters` (`id_semester`),
  CONSTRAINT `fk_semesters` FOREIGN KEY (`id_semester`) REFERENCES `semesters` (`id_semester`) ON UPDATE CASCADE,
  CONSTRAINT `fk_students` FOREIGN KEY (`id_user`) REFERENCES `exchange_students` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key` char(50) NOT NULL,
  `value` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `tandem_learn`;
CREATE TABLE `tandem_learn` (
  `id_tandemuser` int(10) unsigned NOT NULL,
  `id_language` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `tandem_teach`;
CREATE TABLE `tandem_teach` (
  `id_tandemuser` int(10) unsigned NOT NULL,
  `id_language` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `tandem_users`;
CREATE TABLE `tandem_users` (
  `id_tandemuser` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `passhash` char(128) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `id_country` smallint(5) unsigned DEFAULT NULL,
  `about` text,
  `visible` enum('y','n') NOT NULL DEFAULT 'y',
  PRIMARY KEY (`id_tandemuser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `transportation`;
CREATE TABLE `transportation` (
  `id_transportation` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `transportation` varchar(45) NOT NULL,
  `eng` varchar(45) NOT NULL,
  PRIMARY KEY (`id_transportation`),
  UNIQUE KEY `id_transportation_UNIQUE` (`id_transportation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `trips`;
CREATE TABLE `trips` (
  `id_trip` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_event` int(10) unsigned NOT NULL,
  `trip_date_to` timestamp NULL DEFAULT NULL,
  `registration_from` timestamp NULL DEFAULT NULL,
  `capacity` smallint(5) NOT NULL DEFAULT '0',
  `price` smallint(6) NOT NULL DEFAULT '0',
  `type` enum('exchange','buddy','ex+buddy') NOT NULL DEFAULT 'exchange',
  PRIMARY KEY (`id_trip`),
  KEY `id_event` (`id_event`),
  CONSTRAINT `trips_ibfk_2` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `trips_organizers`;
CREATE TABLE `trips_organizers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_trip` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `add_by` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_trip` (`id_trip`),
  KEY `id_user` (`id_user`),
  KEY `add_by` (`add_by`),
  CONSTRAINT `trips_organizers_ibfk_1` FOREIGN KEY (`id_trip`) REFERENCES `trips` (`id_trip`),
  CONSTRAINT `trips_organizers_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `people` (`id_user`),
  CONSTRAINT `trips_organizers_ibfk_3` FOREIGN KEY (`add_by`) REFERENCES `people` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `trips_participants`;
CREATE TABLE `trips_participants` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_trip` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `paid` int(6) unsigned DEFAULT '0',
  `comment` text,
  `registered_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `stand_in` enum('y','n') CHARACTER SET latin1 DEFAULT 'n',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_trip` (`id_trip`),
  KEY `id_user` (`id_user`),
  KEY `registered_by` (`registered_by`),
  KEY `deleted_by` (`deleted_by`),
  CONSTRAINT `trips_participants_ibfk_1` FOREIGN KEY (`id_trip`) REFERENCES `trips` (`id_trip`),
  CONSTRAINT `trips_participants_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `people` (`id_user`),
  CONSTRAINT `trips_participants_ibfk_3` FOREIGN KEY (`registered_by`) REFERENCES `people` (`id_user`),
  CONSTRAINT `trips_participants_ibfk_4` FOREIGN KEY (`deleted_by`) REFERENCES `people` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id_user` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` char(60) DEFAULT NULL,
  `galaxy_username` varchar(255) DEFAULT NULL,
  `hash` char(32) DEFAULT NULL,
  `forgotten_password` char(32) DEFAULT NULL,
  `remember_token` char(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `id_user_UNIQUE` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `users_galaxy_roles`;
CREATE TABLE `users_galaxy_roles` (
  `id_user` int(10) unsigned NOT NULL,
  `id_galaxy_role` int(10) unsigned NOT NULL,
  KEY `id_user` (`id_user`),
  KEY `id_galaxy_role` (`id_galaxy_role`),
  CONSTRAINT `users_galaxy_roles_ibfk_2` FOREIGN KEY (`id_galaxy_role`) REFERENCES `galaxy_roles` (`id_galaxy_role`),
  CONSTRAINT `users_galaxy_roles_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE `users_roles` (
  `id_user` int(10) unsigned NOT NULL,
  `id_role` int(3) unsigned NOT NULL,
  KEY `id_user` (`id_user`),
  KEY `id_role` (`id_role`),
  CONSTRAINT `users_roles_ibfk_4` FOREIGN KEY (`id_role`) REFERENCES `roles` (`id_role`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `users_roles_ibfk_5` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `votes`;
CREATE TABLE `votes` (
  `id_vote` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `best_show` smallint(5) unsigned DEFAULT NULL,
  `best_food` smallint(5) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `id_semester` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id_vote`),
  KEY `id_user` (`id_user`),
  KEY `best_show` (`best_show`),
  KEY `best_food` (`best_food`),
  KEY `id_semester` (`id_semester`),
  CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`),
  CONSTRAINT `votes_ibfk_2` FOREIGN KEY (`best_show`) REFERENCES `countries` (`id_country`),
  CONSTRAINT `votes_ibfk_3` FOREIGN KEY (`best_food`) REFERENCES `countries` (`id_country`),
  CONSTRAINT `votes_ibfk_4` FOREIGN KEY (`id_semester`) REFERENCES `semesters` (`id_semester`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP VIEW IF EXISTS `vwexchange_students`;
CREATE TABLE `vwexchange_students` (`id_user` int(10) unsigned, `email` varchar(100), `first_name` varchar(45), `last_name` varchar(45), `country` varchar(44), `faculty` varchar(38), `dormitory` varchar(45));


DROP TABLE IF EXISTS `arrivals_buddies`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `arrivals_buddies` AS select concat(`pe`.`first_name`,' ',`pe`.`last_name`) AS `exchange name`,`ue`.`email` AS `exchange email`,`arrivals`.`arrival` AS `arrival`,`acc`.`full_name_eng` AS `accommodation`,concat(`pb`.`first_name`,' ',`pb`.`last_name`) AS `buddy name`,`ub`.`email` AS `buddy mail` from (((((((((`exchange_students` `es` join `semesters_has_exchange_students` `s` on((`es`.`id_user` = `s`.`id_user`))) join `arrivals` on((`es`.`id_user` = `arrivals`.`id_user`))) left join `buddies` `b` on((`es`.`id_buddy` = `b`.`id_user`))) join `users` `ue` on((`es`.`id_user` = `ue`.`id_user`))) left join `users` `ub` on((`b`.`id_user` = `ub`.`id_user`))) join `people` `pe` on((`es`.`id_user` = `pe`.`id_user`))) left join `people` `pb` on((`b`.`id_user` = `pb`.`id_user`))) join `accommodation` `acc` on((`es`.`id_accommodation` = `acc`.`id_accommodation`))) join `semesters` `sem` on((`s`.`id_semester` = `sem`.`id_semester`))) where `sem`.`semester` in (select `settings`.`value` from `settings` where (`settings`.`key` = 'currentSemester')) order by `arrivals`.`arrival`;

DROP TABLE IF EXISTS `vwexchange_students`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vwexchange_students` AS select `exchange_students`.`id_user` AS `id_user`,`users`.`email` AS `email`,`people`.`first_name` AS `first_name`,`people`.`last_name` AS `last_name`,`countries`.`full_name` AS `country`,`faculties`.`faculty` AS `faculty`,`accommodation`.`full_name` AS `dormitory` from (((((`exchange_students` join `countries` on((`exchange_students`.`id_country` = `countries`.`id_country`))) join `accommodation` on((`exchange_students`.`id_accommodation` = `accommodation`.`id_accommodation`))) join `faculties` on((`exchange_students`.`id_faculty` = `faculties`.`id_faculty`))) join `people` on((`exchange_students`.`id_user` = `people`.`id_user`))) join `users` on((`exchange_students`.`id_user` = `users`.`id_user`))) order by `exchange_students`.`id_user`;

-- 2018-09-28 18:26:31
